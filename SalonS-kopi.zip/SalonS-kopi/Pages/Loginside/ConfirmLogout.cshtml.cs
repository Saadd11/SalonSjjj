using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalonS.Pages
{
    public class LogoutConfirmedModel : PageModel
    {
        // You can add any logic here if needed
    }
}