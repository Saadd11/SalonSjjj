using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalonS.Pages.Booking;

public class IndexBooking : PageModel
{
    public void OnGet()
    {
        
    }
}