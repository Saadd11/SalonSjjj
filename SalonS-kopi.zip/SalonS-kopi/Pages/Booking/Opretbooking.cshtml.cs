using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SalonS.Pages.Booking;

public class Opretbooking : PageModel
{
    public void OnGet()
    {
        
    }
    
}